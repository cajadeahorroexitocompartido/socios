// ============================================================
//  ÉXITO COMPARTIDO — SISTEMA DE AHORROS Y RETIROS
//  Archivo: Codigo.gs  (proyecto de Apps Script NUEVO e INDEPENDIENTE)
//  ------------------------------------------------------------
//  IMPORTANTE: Este script va en una HOJA DE CÁLCULO NUEVA,
//  distinta a la del sistema de créditos/capital. NO reemplaza
//  ni modifica ese sistema. Se conecta a él únicamente por HTTP,
//  usando la URL pública que ya tienes desplegada, para leer y
//  (cuando haga falta) agregar registros usando las acciones que
//  ese sistema ya expone (leer / agregar / buscar). El código de
//  ese otro sistema no se toca en absoluto.
//
//  PASOS PARA INSTALAR:
//  1) Crea una hoja de cálculo de Google NUEVA (vacía).
//  2) Extensiones → Apps Script → pega este archivo completo.
//  3) Ejecuta la función inicializarHojas() una vez.
//  4) Implementar → Nueva implementación → Aplicación web
//     (Ejecutar como "Yo", acceso "Cualquier usuario").
//  5) Copia la URL /exec y ponla en admin/index.html en la
//     constante ADMIN_APPS_SCRIPT_URL.
// ============================================================

// 🔗 URL del sistema YA EXISTENTE de créditos y capital (NO SE TOCA SU CÓDIGO).
// Solo se usa para leer/agregar datos por HTTP.
const URL_SISTEMA_CREDITOS = "https://script.google.com/macros/s/AKfycby-BrSpUIdQ_v08SYjsg7lFDcMCMxfgbqAjPIlfZZGFRVEoyyTHrRIzJmZFMoUIDAzTFw/exec";

// ── HOJAS PROPIAS DE ESTE SISTEMA (NUEVAS, independientes) ───
const TABS = {
  usuarios : 'Usuarios',           // administradores de ESTE panel (ahorros/retiros)
  ahorros  : 'Ahorros',
  movs     : 'Movimientos_Ahorros',
  accesos  : 'Accesos_Socios',     // credenciales para la futura banca web (cedula + pass + tipo)
  polizas  : 'Polizas',
  config   : 'Configuracion',
};

const HEADERS = {
  usuarios: ['ID','Nombre','Email','Pass','Rol','Activo','FechaCreacion'],

  ahorros: ['ID','Cedula','Nombre','TipoSocio','SaldoActual','TasaAnual','FechaApertura','Activo','FechaCreacion'],

  movs: ['ID','AhorroID','Cedula','Nombre','Tipo','Monto','SaldoAnterior','SaldoResultante','Fecha','Descripcion','RegistradoPor','FechaCreacion'],

  accesos: ['ID','Cedula','Nombre','TipoSocio','PassHash','Activo','UltimoAcceso','FechaCreacion'],

  polizas: ['ID','Cedula','Nombre','Monto','TasaAnual','PlazoMeses','FechaInicio','FechaVencimiento','Estado','Observaciones','FechaCreacion'],

  config: ['ID','Clave','Valor','Descripcion','FechaCreacion'],
};

// ── INICIALIZAR HOJAS DE ESTE SISTEMA ────────────────────────
function inicializarHojas() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  for (const [key, nombre] of Object.entries(TABS)) {
    let hoja = ss.getSheetByName(nombre);
    if (!hoja) hoja = ss.insertSheet(nombre);
    if (hoja.getLastRow() === 0) {
      hoja.appendRow(HEADERS[key]);
      hoja.getRange(1, 1, 1, HEADERS[key].length)
          .setBackground('#0a2647')
          .setFontColor('#d4af37')
          .setFontWeight('bold');
      hoja.setFrozenRows(1);
      hoja.autoResizeColumns(1, HEADERS[key].length);
    }
  }
  const hU = ss.getSheetByName(TABS.usuarios);
  if (hU.getLastRow() <= 1) {
    hU.appendRow([uid(), 'Administrador Ahorros', 'admin.ahorros@exitocompartido.com', 'admin123', 'admin', true, hoy()]);
  }
  const hC = ss.getSheetByName(TABS.config);
  if (hC.getLastRow() <= 1) {
    hC.appendRow([uid(), 'TasaAhorros', '4', 'Tasa de interés ANUAL (%) para cuentas de ahorro', hoy()]);
    hC.appendRow([uid(), 'TasaPolizas', '7', 'Tasa de interés ANUAL (%) por defecto para pólizas', hoy()]);
    hC.appendRow([uid(), 'NombreCaja', 'Caja de Ahorro y Crédito Éxito Compartido', 'Nombre comercial', hoy()]);
  }
  SpreadsheetApp.getUi().alert('✅ Sistema de Ahorros y Retiros inicializado.\n\nAdministrador inicial:\n• admin.ahorros@exitocompartido.com / admin123\n\nEste sistema quedó listo para vincularse por URL al sistema de créditos y capital, sin modificarlo.');
}

function uid() { return Utilities.getUuid().split('-')[0].toUpperCase(); }
function hoy() { return Utilities.formatDate(new Date(), 'America/Guayaquil', 'yyyy-MM-dd'); }
function hashPass(pass) {
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(pass));
  return bytes.map(b => ('0' + (b & 0xFF).toString(16)).slice(-2)).join('');
}

// ── CRUD GENÉRICO SOBRE LAS HOJAS PROPIAS ────────────────────
function leerTodo(tabKey) {
  const ss   = SpreadsheetApp.getActiveSpreadsheet();
  const hoja = ss.getSheetByName(TABS[tabKey]);
  if (!hoja || hoja.getLastRow() <= 1) return [];
  const datos = hoja.getDataRange().getValues();
  const cab   = datos[0];
  return datos.slice(1).map(fila => {
    const obj = {};
    cab.forEach((c, i) => {
      let v = fila[i];
      if (v instanceof Date) v = Utilities.formatDate(v, 'America/Guayaquil', 'yyyy-MM-dd');
      obj[c] = v;
    });
    return obj;
  });
}

function agregar(tabKey, datos) {
  const ss   = SpreadsheetApp.getActiveSpreadsheet();
  const hoja = ss.getSheetByName(TABS[tabKey]);
  const cab  = HEADERS[tabKey];
  datos['ID']            = datos['ID'] || uid();
  datos['FechaCreacion'] = hoy();
  const fila = cab.map(c => datos[c] !== undefined ? datos[c] : '');
  hoja.appendRow(fila);
  return { id: datos['ID'], ...datos };
}

function actualizar(tabKey, id, datosNuevos) {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const hoja  = ss.getSheetByName(TABS[tabKey]);
  const datos = hoja.getDataRange().getValues();
  const cab   = datos[0];
  const idCol = cab.indexOf('ID');
  for (let i = 1; i < datos.length; i++) {
    if (String(datos[i][idCol]) === String(id)) {
      for (const [key, val] of Object.entries(datosNuevos)) {
        const col = cab.indexOf(key);
        if (col >= 0) hoja.getRange(i + 1, col + 1).setValue(val);
      }
      return true;
    }
  }
  return false;
}

function eliminarFila(tabKey, id) {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const hoja  = ss.getSheetByName(TABS[tabKey]);
  const datos = hoja.getDataRange().getValues();
  const cab   = datos[0];
  const idCol = cab.indexOf('ID');
  for (let i = datos.length - 1; i >= 1; i--) {
    if (String(datos[i][idCol]) === String(id)) {
      hoja.deleteRow(i + 1);
      return true;
    }
  }
  return false;
}

// ── CONFIGURACIÓN (clave-valor) ──────────────────────────────
function getConfig(clave) {
  const cfg = leerTodo('config').find(c => c.Clave === clave);
  return cfg ? cfg.Valor : null;
}
function setConfig(clave, valor, descripcion) {
  const cfg = leerTodo('config').find(c => c.Clave === clave);
  if (cfg) { actualizar('config', cfg.ID, { Valor: valor }); return true; }
  agregar('config', { Clave: clave, Valor: valor, Descripcion: descripcion || '' });
  return true;
}

// ============================================================
//  PUENTE HTTP HACIA EL SISTEMA DE CRÉDITOS/CAPITAL (SOLO LECTURA
//  Y ALTA DE REGISTROS, USANDO SU API TAL CUAL YA EXISTE)
// ============================================================
function llamarSistemaCreditos(payload) {
  const res = UrlFetchApp.fetch(URL_SISTEMA_CREDITOS, {
    method: 'post',
    contentType: 'application/json',
    payload: JSON.stringify(payload),
    muteHttpExceptions: true,
  });
  const json = JSON.parse(res.getContentText());
  if (!json.ok) throw new Error(json.error || 'Error al conectar con el sistema de créditos');
  return json.data;
}
function leerRemoto(tab)                  { return llamarSistemaCreditos({ accion: 'leer', tab }); }
function agregarRemoto(tab, datos)        { return llamarSistemaCreditos({ accion: 'agregar', tab, datos }); }
function buscarRemoto(tab, campo, valor)  { return llamarSistemaCreditos({ accion: 'buscar', tab, campo, valor }); }

// ── VINCULAR O CREAR UN SOCIO EN EL SISTEMA REMOTO SEGÚN SU TIPO ─
// Capitalista → se vincula/crea en la hoja "Socios" (remota)
// Ahorrista   → se vincula/crea en la hoja "Clientes" (remota)
function vincularSocioRemoto(d) {
  const cedula = d.Cedula;
  if (d.TipoSocio === 'capitalista') {
    const socios = leerRemoto('socios');
    let existente = socios.find(s => String(s.Cedula) === String(cedula));
    if (!existente) {
      existente = agregarRemoto('socios', {
        Nombres: d.Nombres, Apellidos: d.Apellidos, Cedula: cedula,
        Telefono: d.Telefono || '', Email: d.Email || '',
        FechaIngreso: hoy(), Activo: true,
      });
    }
    return { nombreCompleto: existente.Nombres + ' ' + existente.Apellidos, registro: existente };
  } else {
    const clientes = leerRemoto('clientes');
    let existente = clientes.find(c => String(c.Cedula) === String(cedula));
    if (!existente) {
      existente = agregarRemoto('clientes', {
        Nombres: d.Nombres, Apellidos: d.Apellidos, Cedula: cedula,
        Telefono: d.Telefono || '', Email: d.Email || '', Activo: true,
      });
    }
    return { nombreCompleto: existente.Nombres + ' ' + existente.Apellidos, registro: existente };
  }
}

// ── CREAR SOCIO + ACCESO A BANCA WEB + CUENTA DE AHORROS ─────
function crearSocioYAcceso(d) {
  const vinculo = vincularSocioRemoto(d);
  const nombreCompleto = vinculo.nombreCompleto;

  // Acceso (credenciales banca web)
  const accesos = leerTodo('accesos');
  let acceso = accesos.find(a => String(a.Cedula) === String(d.Cedula));
  const hash = hashPass(d.Pass || Math.random().toString(36).slice(2, 10));
  if (acceso) {
    actualizar('accesos', acceso.ID, { PassHash: hash, Nombre: nombreCompleto, TipoSocio: d.TipoSocio, Activo: true });
  } else {
    acceso = agregar('accesos', {
      Cedula: d.Cedula, Nombre: nombreCompleto, TipoSocio: d.TipoSocio,
      PassHash: hash, Activo: true, UltimoAcceso: '',
    });
  }

  // Cuenta de ahorros (se abre para ambos tipos; el capitalista además tendrá capital remoto)
  const ahorros = leerTodo('ahorros');
  let cuenta = ahorros.find(a => String(a.Cedula) === String(d.Cedula));
  if (!cuenta) {
    const tasaDefault = parseFloat(getConfig('TasaAhorros') || 4);
    cuenta = agregar('ahorros', {
      Cedula: d.Cedula, Nombre: nombreCompleto, TipoSocio: d.TipoSocio,
      SaldoActual: 0, TasaAnual: tasaDefault, FechaApertura: hoy(), Activo: true,
    });
  }

  return { ok: true, msg: 'Socio vinculado y acceso creado correctamente', nombreCompleto, acceso, cuenta };
}

// ── MOVIMIENTOS DE AHORRO (depósito / retiro / interés) ──────
function movimientoAhorro(cedula, nombre, tipo, monto, descripcion, registradoPor) {
  monto = parseFloat(monto || 0);
  if (!monto || monto <= 0) return { ok: false, msg: 'El monto debe ser mayor a 0' };

  let cuenta = leerTodo('ahorros').find(a => String(a.Cedula) === String(cedula));
  if (!cuenta) {
    const tasaDefault = parseFloat(getConfig('TasaAhorros') || 4);
    cuenta = agregar('ahorros', { Cedula: cedula, Nombre: nombre, TipoSocio: '', SaldoActual: 0, TasaAnual: tasaDefault, FechaApertura: hoy(), Activo: true });
  }

  const saldoAnterior = parseFloat(cuenta.SaldoActual || 0);
  let saldoNuevo;
  if (tipo === 'deposito' || tipo === 'interes') {
    saldoNuevo = parseFloat((saldoAnterior + monto).toFixed(2));
  } else if (tipo === 'retiro') {
    if (monto > saldoAnterior) return { ok: false, msg: 'Saldo insuficiente para el retiro' };
    saldoNuevo = parseFloat((saldoAnterior - monto).toFixed(2));
  } else {
    return { ok: false, msg: 'Tipo de movimiento inválido' };
  }

  actualizar('ahorros', cuenta.ID, { SaldoActual: saldoNuevo });
  const mov = agregar('movs', {
    AhorroID: cuenta.ID, Cedula: cedula, Nombre: nombre, Tipo: tipo, Monto: monto,
    SaldoAnterior: saldoAnterior, SaldoResultante: saldoNuevo, Fecha: hoy(),
    Descripcion: descripcion || '', RegistradoPor: registradoPor || '',
  });

  return { ok: true, cuenta: { ...cuenta, SaldoActual: saldoNuevo }, movimiento: mov };
}

function calcularInteresesMensuales() {
  const cuentas = leerTodo('ahorros').filter(c => c.Activo === true || c.Activo === 'true');
  let procesadas = 0;
  cuentas.forEach(c => {
    const saldo = parseFloat(c.SaldoActual || 0);
    if (saldo <= 0) return;
    const tasaAnual = parseFloat(c.TasaAnual || getConfig('TasaAhorros') || 4);
    const interes = parseFloat((saldo * (tasaAnual / 100 / 12)).toFixed(2));
    if (interes <= 0) return;
    movimientoAhorro(c.Cedula, c.Nombre, 'interes', interes, 'Interés mensual generado automáticamente', 'Sistema');
    procesadas++;
  });
  return { ok: true, cuentasProcesadas: procesadas };
}

function crearTriggerMensualIntereses() {
  ScriptApp.getProjectTriggers().forEach(t => {
    if (t.getHandlerFunction() === 'calcularInteresesMensuales') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('calcularInteresesMensuales').timeBased().onMonthDay(1).atHour(2).create();
}

// ── LOGIN DE SOCIO (para la futura banca web) ────────────────
function loginSocio(cedula, pass) {
  const acceso = leerTodo('accesos').find(a => String(a.Cedula) === String(cedula) && (a.Activo === true || a.Activo === 'true'));
  if (!acceso) return { ok: false, msg: 'Cédula no registrada para banca web. Contacte al administrador.' };
  if (acceso.PassHash !== hashPass(pass)) return { ok: false, msg: 'Contraseña incorrecta' };
  actualizar('accesos', acceso.ID, { UltimoAcceso: hoy() });
  return { ok: true, cedula: acceso.Cedula, nombre: acceso.Nombre, tipoSocio: acceso.TipoSocio };
}

// ── RESUMEN COMPLETO POR CÉDULA (mezcla datos propios + remotos) ─
function resumenPorCedula(cedula) {
  const acceso = leerTodo('accesos').find(a => String(a.Cedula) === String(cedula)) || null;
  const tipoSocio = acceso ? acceso.TipoSocio : null;

  const ahorro = leerTodo('ahorros').find(a => String(a.Cedula) === String(cedula)) || null;
  const movimientosAhorro = leerTodo('movs')
    .filter(m => String(m.Cedula) === String(cedula))
    .sort((a, b) => String(b.Fecha).localeCompare(String(a.Fecha)));
  const polizas = leerTodo('polizas').filter(p => String(p.Cedula) === String(cedula));

  let capitalTotal = 0, movimientosCapital = [], socioRemoto = null;
  if (tipoSocio === 'capitalista') {
    const socios = leerRemoto('socios');
    socioRemoto = socios.find(s => String(s.Cedula) === String(cedula)) || null;
    if (socioRemoto) {
      const movs = leerRemoto('capital').filter(m => String(m.SocioID) === String(socioRemoto.ID));
      movimientosCapital = movs.sort((a, b) => String(b.Fecha).localeCompare(String(a.Fecha)));
      capitalTotal = movs.reduce((acc, m) => {
        if (m.Tipo === 'aporte') return acc + (+m.Monto || 0);
        if (m.Tipo === 'retiro' || m.Tipo === 'dividendo') return acc - (+m.Monto || 0);
        return acc;
      }, 0);
    }
  }

  // Créditos: se buscan en el sistema remoto por coincidencia de cédula del cliente
  let creditos = [], clienteRemoto = null;
  const clientes = leerRemoto('clientes');
  clienteRemoto = clientes.find(c => String(c.Cedula) === String(cedula)) || null;
  if (clienteRemoto) {
    const credsAll = leerRemoto('creditos').filter(c => String(c.ClienteID) === String(clienteRemoto.ID));
    const cuotasAll = leerRemoto('cuotas');
    const pagosAll = leerRemoto('pagos').filter(p => {
      const est = String(p.Estado || 'activo').toLowerCase().trim();
      return est !== 'eliminado';
    });
    creditos = credsAll.map(cr => {
      const cuotasCredito = cuotasAll
        .filter(q => String(q.CreditoID) === String(cr.ID))
        .sort((a, b) => a.NumeroCuota - b.NumeroCuota);
      const pagosCredito = pagosAll.filter(p => String(p.CreditoID) === String(cr.ID));
      return { ...cr, cuotas: calcularEstadoCuotas(cr, cuotasCredito, pagosCredito) };
    });
  }

  return {
    tipoSocio, clienteRemoto, socioRemoto,
    ahorro, movimientosAhorro, polizas,
    capitalTotal, movimientosCapital,
    creditos,
  };
}

// ── ESTADO REAL DE LAS CUOTAS (la hoja "Cuotas" del sistema remoto no ─
// se actualiza cuando se registra un pago; el estado real se deduce
// cruzando con la hoja "Pagos" de ese mismo sistema) ─────────────────
function calcularEstadoCuotas(credito, cuotasCredito, pagosCredito) {
  // Si el crédito entero ya está cancelado, todas sus cuotas se muestran así
  if (credito.Estado === 'cancelado') {
    return cuotasCredito.map(q => ({ ...q, EstadoCalculado: 'cancelado' }));
  }

  // 1) Intento preciso: cada pago trae el número de cuota que cancela (NumPago)
  const numerosCuotaPagados = new Set(
    pagosCredito.map(p => String(p.NumPago)).filter(n => n && n !== 'undefined')
  );
  if (numerosCuotaPagados.size > 0) {
    return cuotasCredito.map(q => ({
      ...q,
      EstadoCalculado: numerosCuotaPagados.has(String(q.NumeroCuota)) ? 'pagado' : 'pendiente',
    }));
  }

  // 2) Respaldo: si los pagos no traen NumPago, se asume que los pagos
  // cancelan las cuotas en orden (la 1ra cuota con el 1er pago, etc.)
  const cantidadPagos = pagosCredito.length;
  return cuotasCredito.map((q, idx) => ({
    ...q,
    EstadoCalculado: idx < cantidadPagos ? 'pagado' : 'pendiente',
  }));
}

// ── DASHBOARD DEL PANEL DE AHORROS ───────────────────────────
function calcularDashboard() {
  const ahorros = leerTodo('ahorros');
  const movs    = leerTodo('movs');
  const accesos = leerTodo('accesos');
  const hoyStr  = hoy();
  const mes     = hoyStr.substr(0, 7);
  const movsMes = movs.filter(m => String(m.Fecha).startsWith(mes));

  return {
    totalCuentas: ahorros.length,
    saldoTotal:   ahorros.reduce((a, c) => a + (+c.SaldoActual || 0), 0),
    depositosMes: movsMes.filter(m => m.Tipo === 'deposito').reduce((a, m) => a + (+m.Monto || 0), 0),
    retirosMes:   movsMes.filter(m => m.Tipo === 'retiro').reduce((a, m) => a + (+m.Monto || 0), 0),
    interesesMes: movsMes.filter(m => m.Tipo === 'interes').reduce((a, m) => a + (+m.Monto || 0), 0),
    totalCapitalistas: accesos.filter(a => a.TipoSocio === 'capitalista').length,
    totalAhorristas:   accesos.filter(a => a.TipoSocio === 'ahorrista').length,
    ultimosMovimientos: [...movs].sort((a, b) => String(b.Fecha).localeCompare(String(a.Fecha))).slice(0, 50),
  };
}

// ============================================================
//  MANEJADOR PRINCIPAL DE PETICIONES
// ============================================================
function doGet(e)  { return manejar(e); }
function doPost(e) { return manejar(e); }

function manejar(e) {
  const output = ContentService.createTextOutput();
  output.setMimeType(ContentService.MimeType.JSON);

  try {
    const params = e.parameter || {};
    const body   = e.postData ? JSON.parse(e.postData.contents || '{}') : {};
    const accion = params.accion || body.accion;
    const tab    = params.tab    || body.tab;
    let resultado;

    switch (accion) {

      // ── Autenticación del panel administrativo ──────────────
      case 'login': {
        const usuarios = leerTodo('usuarios');
        const u = usuarios.find(x => x.Email === body.email && x.Pass === body.pass && (x.Activo === true || x.Activo === 'true'));
        resultado = u
          ? { ok: true, usuario: { id: u.ID, nombre: u.Nombre, rol: u.Rol, email: u.Email } }
          : { ok: false, msg: 'Correo o contraseña incorrectos' };
        break;
      }

      // ── CRUD genérico sobre hojas PROPIAS (ahorros, movs, accesos, polizas, config, usuarios) ─
      case 'leer_local':
        resultado = leerTodo(tab);
        break;

      case 'agregar_local':
        resultado = agregar(tab, body.datos || {});
        break;

      case 'actualizar_local':
        resultado = actualizar(tab, body.id, body.datos || {});
        break;

      case 'eliminar_local':
        resultado = eliminarFila(tab, body.id || params.id);
        break;

      // ── Puente de solo lectura/alta hacia el sistema de créditos ─
      case 'leer_remoto':
        resultado = leerRemoto(tab);
        break;

      case 'buscar_remoto':
        resultado = buscarRemoto(tab, body.campo, body.valor);
        break;

      // ── Gestión de socios (capitalista / ahorrista) ─────────
      case 'crear_socio_acceso':
        resultado = crearSocioYAcceso(body.datos || {});
        break;

      // ── Ahorros ──────────────────────────────────────────────
      case 'movimiento_ahorro': {
        const d = body.datos || {};
        resultado = movimientoAhorro(d.Cedula, d.Nombre, d.Tipo, d.Monto, d.Descripcion, d.RegistradoPor);
        break;
      }

      case 'calcular_intereses_ahorros':
        resultado = calcularInteresesMensuales();
        break;

      // ── Resumen combinado por cédula (propio + remoto) ───────
      case 'resumen_cedula':
        resultado = resumenPorCedula(body.cedula || params.cedula);
        break;

      case 'login_socio':
        resultado = loginSocio(body.cedula, body.pass);
        break;

      case 'dashboard':
        resultado = calcularDashboard();
        break;

      case 'config_get':
        resultado = leerTodo('config');
        break;

      case 'config_set': {
        const d = body.datos || {};
        resultado = setConfig(d.Clave, d.Valor, d.Descripcion);
        break;
      }

      default:
        resultado = { error: 'Acción no reconocida: ' + accion };
    }

    output.setContent(JSON.stringify({ ok: true, data: resultado }));
  } catch (err) {
    output.setContent(JSON.stringify({ ok: false, error: err.message }));
  }

  return output;
}

// ── MENÚ EN GOOGLE SHEETS ────────────────────────────────────
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('⚙️ Ahorros y Retiros')
    .addItem('Inicializar base de datos', 'inicializarHojas')
    .addItem('Crear trigger mensual de intereses', 'crearTriggerMensualIntereses')
    .addItem('Calcular intereses AHORA', 'calcularInteresesMensuales')
    .addToUi();
}
